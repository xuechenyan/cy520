/**
 * Created by bjwsl-001 on 2017/9/6.
 */


var app = angular.module('kflModule', ['ionic']);

//创建一个自定义的服务
app.service('$kflHttp',
  function ($ionicLoading, $http) {
    //封装一个方法
    this.sendRequest = function (url, func) {
      //显示一个加载中的窗口 $ionicLoading
      $ionicLoading.show(
        {
          template: '正在加载数据'
        }
      );
      //发起网络请求
      $http
        .get(url)
        .success(function (data) {
          //data就是服务器返回的数据
          $ionicLoading.hide();
          func(data);
        })
        .error(function () {
          $ionicLoading.hide();
        })
    }
  });


//采用uiRouter来管理ionic所有的代码片段的访问、跳转、传参
app.config(
  function ($stateProvider, $urlRouterProvider) {
    //给每一个代码片段来添加状态
    $stateProvider
      .state('kflStart', {
        url: '/start',
        templateUrl: 'tpl/start.html'
      })
      .state('kflMain', {
        url: '/main',
        templateUrl: 'tpl/main.html',
        controller:'mainCtrl'
      })
      .state('kflDetail', {
        url: '/detail',
        templateUrl: 'tpl/detail.html'
      })
      .state('kflOrder', {
        url: '/order',
        templateUrl: 'tpl/order.html'
      }).state('kflMyOrder', {
        url: '/myOrder',
        templateUrl: 'tpl/myOrder.html'
      })

    //异常处理
    $urlRouterProvider.otherwise('/start');

  });

//给body创建一个控制器
app.controller('bodyCtrl', ['$scope', '$state',
  function ($scope, $state) {

    $scope.jump = function (desState, args) {
      $state.go(desState, args);
    }

  }
]);


//给main创建一个控制器
app.controller('mainCtrl', ['$scope', '$kflHttp',
  function ($scope, $kflHttp) {
    $scope.dishList = [];
    $scope.hasMore = true;
    $scope.myInput = {
      kw:''
    }
    //①页面加载就有列表 ②加载更多 ③搜索功能
    $kflHttp.sendRequest(
      'data/dish_getbypage.php?start=0',
      function (data) {
        console.log(data);
        $scope.dishList = data;
      }
    );
    //加载更多
    $scope.loadMore = function () {
      $kflHttp.sendRequest(
        'data/dish_getbypage.php?start='+$scope.dishList.length,
        function (data) {
          if(data.length < 5)
          {
            $scope.hasMore = false;
          }
          $scope.dishList =
            $scope.dishList.concat(data);
        }
      )
    }

    //监听
    $scope.$watch('myInput.kw', function () {
      console.log($scope.myInput.kw);
      if($scope.myInput.kw.length > 0)
      {
        //发起请求
        $kflHttp.sendRequest(
          'data/dish_getbykw.php?kw='
            +$scope.myInput.kw,
          function (data) {
            if(data.length > 0)
            {
              $scope.dishList = data;
            }
          }
        )
      }
    })

  }
])







